
%扰动对比
figure(1)
hold on
plot(NO,'b');
plot(PID(200:2000),'y');
plot(F_PID(200:2000),'r')

%上升对比
figure(2)
hold on
plot(PID(1:100),'y');
plot(F_PID(1:100),'r')

%统计值对比
jicha=[max(NO)-min(NO) max(PID(200:2000))-min(PID(200:2000)) max(F_PID(200:2000))-min(F_PID(200:2000))]%极差
biaozhuncha=[std(NO) std(PID(200:2000)) std(F_PID(200:2000))]%标准差
pingjunzhi=[mean(NO) mean(PID(200:2000)) mean(F_PID(200:2000))]%均值
sifenweicha=[iqr(NO) iqr(PID(200:2000)) iqr(F_PID(200:2000))]%四分位差
