I=smooth(I);
V=smooth(V);
P=smooth(P);
T=smooth(T);

PD=V.*I;%电功率
EP=smooth((P./PD))*1E3;%发光效率

%光电热模型
PET=(5.811*I-0.5142).*(-0.001891*T+1.418);
PET=PET(1:150);
E_PET=abs(PET-P);
PET=PET-(max(E_PET)+min(E_PET))/2;
E_PET=abs(PET-P);
plot(PET)
hold on
plot(P)
max(E_PET)
std(E_PET)
mean(E_PET)
plot(E_PET)

%传统模型
LIN=7.938*I-3.912;
LIN=LIN(1:150);
E_LIN=abs(LIN-P);
LIN=LIN-(max(E_LIN)+min(E_LIN))/2;
E_LIN=abs(LIN-P);
plot(LIN)
hold on
plot(P)
max(E_LIN)
std(E_LIN)
mean(E_LIN)
plot(E_LIN)

%对比
plot(P)
hold on
plot(LIN)
plot(PET)

plot(smooth(E_LIN))
hold on
plot(smooth(E_PET))